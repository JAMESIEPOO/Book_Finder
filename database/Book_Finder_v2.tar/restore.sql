--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2
-- Dumped by pg_dump version 17.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Book_Finder";
--
-- Name: Book_Finder; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Book_Finder" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE "Book_Finder" OWNER TO postgres;

\connect "Book_Finder"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Author; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Author" (
    "authorID" bigint NOT NULL,
    authorname name NOT NULL,
    biography text
);


ALTER TABLE public."Author" OWNER TO postgres;

--
-- Name: Book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Book" (
    "bookID" bigint NOT NULL,
    title character varying(100) NOT NULL,
    "authorID" bigint NOT NULL,
    genre character varying(20) NOT NULL,
    summery text,
    rating double precision NOT NULL,
    "publisherID" bigint NOT NULL,
    "date published" date NOT NULL
);


ALTER TABLE public."Book" OWNER TO postgres;

--
-- Name: Favorites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Favorites" (
    "userID" bigint,
    "bookID" bigint
);


ALTER TABLE public."Favorites" OWNER TO postgres;

--
-- Name: Preferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Preferences" (
    "preferenceID" bigint NOT NULL,
    genre character varying(20),
    author character varying(20),
    rating double precision DEFAULT 0
);


ALTER TABLE public."Preferences" OWNER TO postgres;

--
-- Name: Publisher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Publisher" (
    "publisherID" bigint NOT NULL,
    "publisherName" character varying(50) NOT NULL,
    "publisherInfo" text
);


ALTER TABLE public."Publisher" OWNER TO postgres;

--
-- Name: Review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Review" (
    "reviewID" bigint NOT NULL,
    "bookID" bigint NOT NULL,
    "userID" bigint NOT NULL,
    rating double precision NOT NULL,
    "reviewText" text,
    "timestamp" timestamp with time zone NOT NULL
);


ALTER TABLE public."Review" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    "userID" bigint NOT NULL,
    username name NOT NULL COLLATE pg_catalog."default",
    email character varying(254) NOT NULL,
    password character varying(20) NOT NULL,
    "preferenceID" bigint
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Data for Name: Author; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Author" ("authorID", authorname, biography) FROM stdin;
\.
COPY public."Author" ("authorID", authorname, biography) FROM '$$PATH$$/4935.dat';

--
-- Data for Name: Book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Book" ("bookID", title, "authorID", genre, summery, rating, "publisherID", "date published") FROM stdin;
\.
COPY public."Book" ("bookID", title, "authorID", genre, summery, rating, "publisherID", "date published") FROM '$$PATH$$/4934.dat';

--
-- Data for Name: Favorites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Favorites" ("userID", "bookID") FROM stdin;
\.
COPY public."Favorites" ("userID", "bookID") FROM '$$PATH$$/4937.dat';

--
-- Data for Name: Preferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Preferences" ("preferenceID", genre, author, rating) FROM stdin;
\.
COPY public."Preferences" ("preferenceID", genre, author, rating) FROM '$$PATH$$/4933.dat';

--
-- Data for Name: Publisher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Publisher" ("publisherID", "publisherName", "publisherInfo") FROM stdin;
\.
COPY public."Publisher" ("publisherID", "publisherName", "publisherInfo") FROM '$$PATH$$/4938.dat';

--
-- Data for Name: Review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Review" ("reviewID", "bookID", "userID", rating, "reviewText", "timestamp") FROM stdin;
\.
COPY public."Review" ("reviewID", "bookID", "userID", rating, "reviewText", "timestamp") FROM '$$PATH$$/4936.dat';

--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" ("userID", username, email, password, "preferenceID") FROM stdin;
\.
COPY public."User" ("userID", username, email, password, "preferenceID") FROM '$$PATH$$/4932.dat';

--
-- Name: Author Author_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Author"
    ADD CONSTRAINT "Author_pkey" PRIMARY KEY ("authorID");


--
-- Name: Book Book_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Book"
    ADD CONSTRAINT "Book_pkey" PRIMARY KEY ("bookID");


--
-- Name: Preferences Preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Preferences"
    ADD CONSTRAINT "Preferences_pkey" PRIMARY KEY ("preferenceID");


--
-- Name: Publisher Publisher_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Publisher"
    ADD CONSTRAINT "Publisher_pkey" PRIMARY KEY ("publisherID");


--
-- Name: Review Review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_pkey" PRIMARY KEY ("reviewID");


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY ("userID");


--
-- Name: User user_uniquekey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT user_uniquekey UNIQUE ("userID");


--
-- Name: Book Book_fkey_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Book"
    ADD CONSTRAINT "Book_fkey_1" FOREIGN KEY ("authorID") REFERENCES public."Author"("authorID") NOT VALID;


--
-- Name: Review Review_fkey_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_fkey_1" FOREIGN KEY ("bookID") REFERENCES public."Book"("bookID");


--
-- Name: Review Review_fkey_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_fkey_2" FOREIGN KEY ("userID") REFERENCES public."User"("userID");


--
-- Name: User User_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_fkey" FOREIGN KEY ("preferenceID") REFERENCES public."Preferences"("preferenceID") NOT VALID;


--
-- Name: Book book_fkey_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Book"
    ADD CONSTRAINT book_fkey_2 FOREIGN KEY ("publisherID") REFERENCES public."Publisher"("publisherID") NOT VALID;


--
-- Name: Favorites favorites_fkey_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Favorites"
    ADD CONSTRAINT favorites_fkey_1 FOREIGN KEY ("userID") REFERENCES public."User"("userID");


--
-- Name: Favorites favorites_fkey_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Favorites"
    ADD CONSTRAINT favorites_fkey_2 FOREIGN KEY ("bookID") REFERENCES public."Book"("bookID");


--
-- PostgreSQL database dump complete
--

