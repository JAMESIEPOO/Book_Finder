--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2
-- Dumped by pg_dump version 17.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Book_Finder";
--
-- Name: Book_Finder; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Book_Finder" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE "Book_Finder" OWNER TO postgres;

\connect "Book_Finder"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: sq_author_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sq_author_id
    START WITH 8
    INCREMENT BY 1
    MINVALUE 8
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sq_author_id OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Author; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Author" (
    "authorID" bigint DEFAULT nextval('public.sq_author_id'::regclass) NOT NULL,
    authorname name NOT NULL,
    biography text
);


ALTER TABLE public."Author" OWNER TO postgres;

--
-- Name: sq_book_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sq_book_id
    START WITH 12
    INCREMENT BY 1
    MINVALUE 12
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sq_book_id OWNER TO postgres;

--
-- Name: Book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Book" (
    "bookID" bigint DEFAULT nextval('public.sq_book_id'::regclass) NOT NULL,
    title character varying(100) NOT NULL,
    "authorID" bigint,
    summery text,
    rating bigint NOT NULL,
    "publisherID" bigint NOT NULL,
    "date published" date NOT NULL,
    "genreID" bigint
);


ALTER TABLE public."Book" OWNER TO postgres;

--
-- Name: Favorites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Favorites" (
    "userID" bigint,
    "bookID" bigint
);


ALTER TABLE public."Favorites" OWNER TO postgres;

--
-- Name: sq_genre_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sq_genre_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sq_genre_id OWNER TO postgres;

--
-- Name: Genre; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Genre" (
    "genreID" bigint DEFAULT nextval('public.sq_genre_id'::regclass) NOT NULL,
    "genreName" character varying(20) NOT NULL
);


ALTER TABLE public."Genre" OWNER TO postgres;

--
-- Name: sq_publisher_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sq_publisher_id
    START WITH 9
    INCREMENT BY 1
    MINVALUE 9
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sq_publisher_id OWNER TO postgres;

--
-- Name: Publisher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Publisher" (
    "publisherID" bigint DEFAULT nextval('public.sq_publisher_id'::regclass) NOT NULL,
    "publisherName" character varying(50) NOT NULL,
    "publisherInfo" text
);


ALTER TABLE public."Publisher" OWNER TO postgres;

--
-- Name: sq_review_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sq_review_id
    START WITH 5
    INCREMENT BY 1
    MINVALUE 5
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sq_review_id OWNER TO postgres;

--
-- Name: Review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Review" (
    "reviewID" bigint DEFAULT nextval('public.sq_review_id'::regclass) NOT NULL,
    "bookID" bigint NOT NULL,
    "userID" bigint NOT NULL,
    rating bigint NOT NULL,
    "reviewText" text,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."Review" OWNER TO postgres;

--
-- Name: sq_user_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sq_user_id
    START WITH 8
    INCREMENT BY 1
    MINVALUE 8
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sq_user_id OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    "userID" bigint DEFAULT nextval('public.sq_user_id'::regclass) NOT NULL,
    username name NOT NULL COLLATE pg_catalog."default",
    email character varying(254) NOT NULL,
    password character varying(128) NOT NULL,
    rating double precision,
    "authorID" bigint,
    "genreID" bigint
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Data for Name: Author; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Author" ("authorID", authorname, biography) FROM stdin;
\.
COPY public."Author" ("authorID", authorname, biography) FROM '$$PATH$$/4948.dat';

--
-- Data for Name: Book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Book" ("bookID", title, "authorID", summery, rating, "publisherID", "date published", "genreID") FROM stdin;
\.
COPY public."Book" ("bookID", title, "authorID", summery, rating, "publisherID", "date published", "genreID") FROM '$$PATH$$/4947.dat';

--
-- Data for Name: Favorites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Favorites" ("userID", "bookID") FROM stdin;
\.
COPY public."Favorites" ("userID", "bookID") FROM '$$PATH$$/4950.dat';

--
-- Data for Name: Genre; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Genre" ("genreID", "genreName") FROM stdin;
\.
COPY public."Genre" ("genreID", "genreName") FROM '$$PATH$$/4957.dat';

--
-- Data for Name: Publisher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Publisher" ("publisherID", "publisherName", "publisherInfo") FROM stdin;
\.
COPY public."Publisher" ("publisherID", "publisherName", "publisherInfo") FROM '$$PATH$$/4951.dat';

--
-- Data for Name: Review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Review" ("reviewID", "bookID", "userID", rating, "reviewText", "timestamp") FROM stdin;
\.
COPY public."Review" ("reviewID", "bookID", "userID", rating, "reviewText", "timestamp") FROM '$$PATH$$/4949.dat';

--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" ("userID", username, email, password, rating, "authorID", "genreID") FROM stdin;
\.
COPY public."User" ("userID", username, email, password, rating, "authorID", "genreID") FROM '$$PATH$$/4946.dat';

--
-- Name: sq_author_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sq_author_id', 12, true);


--
-- Name: sq_book_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sq_book_id', 21, true);


--
-- Name: sq_genre_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sq_genre_id', 6, true);


--
-- Name: sq_publisher_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sq_publisher_id', 13, true);


--
-- Name: sq_review_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sq_review_id', 17, true);


--
-- Name: sq_user_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sq_user_id', 10, true);


--
-- Name: Author Author_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Author"
    ADD CONSTRAINT "Author_pkey" PRIMARY KEY ("authorID");


--
-- Name: Book Book_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Book"
    ADD CONSTRAINT "Book_pkey" PRIMARY KEY ("bookID");


--
-- Name: Genre Genre_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Genre"
    ADD CONSTRAINT "Genre_pkey" PRIMARY KEY ("genreID");


--
-- Name: Publisher Publisher_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Publisher"
    ADD CONSTRAINT "Publisher_pkey" PRIMARY KEY ("publisherID");


--
-- Name: Review Review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_pkey" PRIMARY KEY ("reviewID");


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY ("userID");


--
-- Name: User user_uniquekey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT user_uniquekey UNIQUE ("userID");


--
-- Name: Review Review_fkey_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_fkey_1" FOREIGN KEY ("bookID") REFERENCES public."Book"("bookID");


--
-- Name: Review Review_fkey_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Review"
    ADD CONSTRAINT "Review_fkey_2" FOREIGN KEY ("userID") REFERENCES public."User"("userID");


--
-- Name: Favorites favorites_fkey_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Favorites"
    ADD CONSTRAINT favorites_fkey_1 FOREIGN KEY ("userID") REFERENCES public."User"("userID");


--
-- Name: Favorites favorites_fkey_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Favorites"
    ADD CONSTRAINT favorites_fkey_2 FOREIGN KEY ("bookID") REFERENCES public."Book"("bookID");


--
-- Name: Book fk_book_author_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Book"
    ADD CONSTRAINT fk_book_author_id FOREIGN KEY ("authorID") REFERENCES public."Author"("authorID") NOT VALID;


--
-- Name: Book fk_book_genre_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Book"
    ADD CONSTRAINT fk_book_genre_id FOREIGN KEY ("genreID") REFERENCES public."Genre"("genreID") NOT VALID;


--
-- Name: Book fk_book_publisher_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Book"
    ADD CONSTRAINT fk_book_publisher_id FOREIGN KEY ("publisherID") REFERENCES public."Publisher"("publisherID") NOT VALID;


--
-- Name: User fk_user_author_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT fk_user_author_id FOREIGN KEY ("authorID") REFERENCES public."Author"("authorID") NOT VALID;


--
-- Name: User fk_user_genre_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT fk_user_genre_id FOREIGN KEY ("genreID") REFERENCES public."Genre"("genreID") NOT VALID;


--
-- PostgreSQL database dump complete
--

